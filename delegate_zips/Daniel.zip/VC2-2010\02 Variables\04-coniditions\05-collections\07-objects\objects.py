class Rectangle:
    pass

rect1 = Rectangle()
print(rect1)

class Rectangle:
    def __init__(self):
        self.width=0
        self.hight=0
        pass
rect2 = Rectangle()
rect2.width = 2
rect2.hight = 2
print(rect2.width)
print(rect2.hight)
print(rect2)


class Rectangle:
    def __init__(self, width, hight):
        self.width=width
        self.hight=hight
    def area(self):
        return self.width * self.hight
    pass
rect3 = Rectangle(4,5)
print(rect3.width)
print(rect3.hight)
print(rect3)
print(rect3.area())
print(rect3)

class Rectangle:
    def __init__(self, width, hight):
        self.width=width
        self.hight=hight
    def area(self):
        return self.width * self.hight
    def __str__(self):
        return f"Rectangle width: {self.width} hight: {self.hight}"

rect4 = Rectangle(8,10)
print(rect4.width)
print(rect4.hight)
print(rect4.area())
print(rect4)