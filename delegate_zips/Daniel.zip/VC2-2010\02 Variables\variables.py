# int

my_number = 42     #initialistaion - first time the variable pops up in code
print(isinstance(my_number, int))#True
print(my_number.is_integer())#True
print(type(my_number))#<class 'int'>

#float
my_number = 42.0     #re-assignment
print(isinstance(my_number, float))#True
print(type(my_number))#(Class 'float'

#complex
my_number = 1 + 1j#real and imaginary parts
#used for things like calculating the square root of a negative number
print(type(my_number))#class 'complex')

#boolean
my_boolean = True
print(type(my_boolean))#class 'bool'

#string
my_string = "Hello"
print(type(my_string))##,class 'str'

#the container types holld multile values, referrenced by one variable
numbers = [1,2,3]
print(len(numbers))
print(type(numbers))
print(numbers[0])
print(numbers[2])

print(len(my_string))
print(my_string[0])

#None
my_none = None
print(type(my_none))
my_string = None
print(my_string)