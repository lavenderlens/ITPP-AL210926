print("Entre a number")
num1 = input()
print(num1)
print(type(num1))

num2 = input("enter another nunber")
print(type(num2))

print(num1 + num2)

num1 = float(num1)
print(type(num1))
num2 = float(num2)
print(num1 + num2)

