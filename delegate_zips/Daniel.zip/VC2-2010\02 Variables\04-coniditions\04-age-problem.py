age = input ("What is your age?")
age = int(age)
if age < 18:
    print("You are a minor")
elif age < 65:
    print ("You are of working age")
else:
    print ("you are eligable for retirement")