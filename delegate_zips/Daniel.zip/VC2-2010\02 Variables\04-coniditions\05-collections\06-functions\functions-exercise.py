def greet():
    print ("Hello")
    print ("How are you")
print ("Hi")
greet()