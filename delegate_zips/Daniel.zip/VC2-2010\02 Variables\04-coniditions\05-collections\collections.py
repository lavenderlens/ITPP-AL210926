names = ["Erik", "Daniel", "Alan"]
print (names)
names.append("Bertrand Russell")
print (names)

names[0] +=" de Greef"
names[1] +=" Hayter"
names[2] +=" Lavender"

print (names)

del names[3]

print (names)