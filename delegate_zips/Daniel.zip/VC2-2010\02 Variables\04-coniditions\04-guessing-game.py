import random
magic_number = random.randint(1, 10)
print (magic_number)
user_guess = input ("Guess the maginc number")
user_guess = int(user_guess)
if user_guess == magic_number:
    print ("You got it")
elif user_guess + 1 == magic_number or user_guess - 1 == magic_number:
    print ("So close")
else:
    print ("Wrong")