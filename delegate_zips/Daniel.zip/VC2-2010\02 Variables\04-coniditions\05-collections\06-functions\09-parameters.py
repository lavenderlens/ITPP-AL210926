def print_sum(number1, number2):
    result = number1 + number2
    print (result)

def print_product(number1, number2):
    result = number1 * number2
    print (result)

num1 = input("enter first number")
num1 = int(num1)

num2 = input("Enter second number")
num2 = int(num2)
operation = input ("enter 1 for sum or 2 for prduct")
operation = int(operation)

if operation == 1:
    print_sum(num1, num2)
elif operation == 2:
    print_product(num1,num2)
