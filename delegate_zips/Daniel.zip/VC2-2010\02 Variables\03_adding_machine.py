num1=input("Entre a number")
num1=int(num1)
num2=input("Entre another number")
num2=int(num2)
result=num1 + num2
print(result)