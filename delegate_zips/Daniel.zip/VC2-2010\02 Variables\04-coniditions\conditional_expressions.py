temp = 37
if temp > 20 and temp <= 35:
    print("It's warm")
elif temp > 35:
    print("why did we book this holiday")

else:
    print("it's cool")