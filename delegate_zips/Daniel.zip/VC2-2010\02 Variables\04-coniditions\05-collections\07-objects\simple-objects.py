class Book():

    def __init__(self, title, author):
        self.title=title
        self.author=author

book1 = Book("On Liberty", "Mill")


print(book1.author)
print(book1.title)

book1.author= ("John Stewart Mill")

print(book1.author)

book2 = Book("The Last Casualty", "Ben Elton")

book2.title = "The First Casualty"

print(book2.author)
print(book2.title)





    