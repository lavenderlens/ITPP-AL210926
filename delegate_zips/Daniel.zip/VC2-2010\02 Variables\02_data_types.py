name = "Smith"
number = 43317878
balance = 250.70
is_taxable = True

print(name)
print(number)
print(balance)
print (is_taxable)

print(type(name))
print(type(number))
print(type(balance))
print(type(is_taxable))
      