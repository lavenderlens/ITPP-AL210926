for x in range (1,6):
    print (x)

    print ("# while loop with counter")
    counter = 1
    while counter < 6:
        print (counter)
        counter +=1

        print ("# while loop with collection")
        counties = ["Kent", "Surrey", "Suffolk"]
        index=[0]
        while index < len(counties):
            print (counties[index])
            index += 1

        print ("# for loop with collection")
        for county in counties:
            print (county)

        print ("# break, while loop with collection")
        x =1
        while True:
            if x == 6:
                break
            print (x)
            x += 1

        print ("# break, for loop with collection")
        for county in counties:
            if county == "Surrey":
               break
            print (county)

        print ("# break, while loop with collection")
        index = 0
        while count < len(counties):
           if county == "Surrey":
              break
           print (counties[count])
           count += 1