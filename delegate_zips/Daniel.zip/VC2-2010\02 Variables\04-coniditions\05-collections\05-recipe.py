ingredients = ["chicken", "breadcrumbs", "salt", "garlic", "lime"]
print ("Original")
print (ingredients)
ingredients [4] = ("Lemon")
print ("After changes")
print (ingredients)
ingredients.append ("Rocket")
del ingredients [2]
print ("After changes")
print (ingredients)