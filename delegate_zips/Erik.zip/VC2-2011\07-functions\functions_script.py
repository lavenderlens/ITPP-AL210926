from functions_module import greet_to, print_all, print_sum, get_sum

greet_to()

print_all(["Alan", "Daniel", "Erik"])

print_sum([1,2,3,4])

get_sum([1,2,3,4])
print(get_sum([1,2,3,4]))