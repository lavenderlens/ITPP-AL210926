user_age = int(input("What is your age? "))
if user_age < 18:
    print("Your are minor")
if user_age >= 18 and user_age < 65:
    print("You are of working age")
if user_age >= 65 and user_age < 150:
    print("You are eligible for retirement")
