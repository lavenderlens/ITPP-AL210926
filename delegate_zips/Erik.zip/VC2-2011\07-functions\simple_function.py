def my_function():
    print("This is my function")
    print("Hello")

my_function()

