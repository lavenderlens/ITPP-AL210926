#Q1
for counter in range(3):
    print("Hello")

SET count to 1
WHILE count less than OR equal to 3
    OUTPUT "Hello" to screen
    SET count to count +1
ENDWHILE

#Q2
number=int(input("Enter a number: "))
for i in range(number+1):
    print(i)

INPUT number



#Q3
names = ["Tom", "Dick", "Harry"]
print("name: ")
for name in names:
    print(name)

SET array to ["Tom", "Dick", "Harry"]
FOR name in array
    OUTPUT name
ENDFOR

#Q4

