name="Smith"
number=43317878
balance=250.70
is_taxable=True

print("name: " + name)
print("number: " + str(number))
print("balance: " + str(balance))
print("is_taxable: " + str(is_taxable))