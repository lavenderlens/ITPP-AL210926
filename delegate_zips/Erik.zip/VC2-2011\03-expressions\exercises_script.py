number1=float(input("Enter the first number"))
number2=float(input("Enter the second number"))

total=number1+number2

print("The total is: ", total)

num1=int(str("Enter the first number"))
num2=int(str("Enter the second number"))

result=num1+num2

print("The sum is: ", result)