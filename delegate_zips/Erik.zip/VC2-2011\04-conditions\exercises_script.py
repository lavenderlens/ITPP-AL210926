Q1
INPUT temperature

IF temperature is <= 10 THEN
    OUTPUT "You'll need a coat"
ELSE
    OUTPUT "You don't need a coat"
ENDIF

Q2
INPUT year

IF year MOD 4 ==0 then
    OUTPUT "It's a leap year"
ELSE 
    OUTPUT "It's not a leap year"
ENDIF

Q3
INPUT score

IF score is >= 51 then
    OUTPUT "You have passed the exam"
ELSE 
    OUTPUT "You have not passed the exam"
ENDIF

Q4
INPUT guess

IF guess is ==3 THEN
    "You are right"
ELSE 
    "Unfortunately, that is not correct"

Q5

INPUT age

IF age is <18 THEN
    "You are a minor"
ELSE IF age is <65 THEN
    "You are of working age"
ELSE 
    "You are eligible for retirement"
ENDIF

Q7
No max number

Q8
It is part of the statement above
