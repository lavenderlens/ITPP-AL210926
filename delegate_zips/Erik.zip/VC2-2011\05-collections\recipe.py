ingredients = ["chicken", "breadcrumbs", "salt", "garlic", "lime"]
original = ingredients
original[4] = "lemon"
print(original) #check
original.append("rocket")
print(original) #check
del original[2]
print(original) #check
after_changes = original
print(after_changes) #check

ingredients = ["chicken", "breadcrumbs", "salt", "garlic", "lime"]
print("ORIGINAL")
print(ingredients)
for ingredient in ingredients:
    print(ingredient)

ingredients[4] = "lemon"
ingredients.append("rocket")
del ingredients[2]

print("AFTER CHANGES")
print(ingredients)
for ingredient in ingredients:
    print(ingredient)
