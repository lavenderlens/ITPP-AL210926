Q1
A collection is a list of things, names etc

Q2
That means that each value in the collection has an index assigned starting with 0

Q3
specify array followed by index

Q4
can do that manually or using a file

beverages=["Water", "Beer", "Coffee"]
    OUTPUT beverages [1]
ENDBEVERAGES

Q5
INPUT door 

doors=["door 1", "door 2", "door 3", "door 4", "door 5"]
doors[0]=prize
doors[1]=tiger
doors[2]=tiger
doors[3]=tiger
doors[4]=tiger

#Q5 second try
BEGIN
SET doors TO=["tiger", "tiger", "prize", "tiger", "tiger"]
OUTPUT "Choose a door (1-5)"
INPUT UserGuess
OUTPUT doors[UserGuess -1]
END 

#Q6
BEGIN
SET Coordinates TO [0, 0, 0]
OUTPUT "choose a direction (move up, down, left, right, in, out)"
INPUT UserChoice

IF UserChoice = "move up" THEN
    Coordinates[1] = Coordinates[1]+1
ELSE IF UserChoice = "down" THEN
    Coordinates[1] = Coordinates[1]-1
ELSE IF UserChoice = "left" THEN
    Coordinates[0] = Coordinates[0]-1
ELSE IF UserChoice = "right" THEN
    Coordinates[0] = Coordinates[0]+1
ELSE IF UserChoice = "in" THEN
    Coordinates[2] = Coordinates[2]+1
ELSE IF UserChoice = "out" THEN
    Coordinates[2] = Coordinates[2]-1
ENDIF
END 



