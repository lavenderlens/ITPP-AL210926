for x in range(1,6):
    print(x)

print("while loop with counter")
counter = 1
while counter < 6:
    print(counter)
    counter+=1