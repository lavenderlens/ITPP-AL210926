import random
magicNumber=random.randint(1,10)
print(magicNumber)
user_guess=int(input("Guess the magic number"))
if user_guess==magicNumber:
    print("You got it!")
elif user_guess==magicNumber + 1 or user_guess==magicNumber - 1:
    print("So close!")
else:
    print("Wrong!")
