class Rectangle:
    pass

rect1=Rectangle()
print(rect1)
print(rect1.__str__())

class Rectangle:
    def __init__(self):
        self.width=0
        self.height=0
        pass

rect2= Rectangle()
rect2.width=2
rect2.height=2
print(rect2.width)
print(rect2.height)
print(rect2)

class Rectangle:
    def __init__(self, width, height):
        self.width=width
        self.height=height
    def area(self):
        return self.width*self.height
    pass

rect3=Rectangle(4,5)
print(rect3.width)
print(rect3.height)
print(rect3.area())
print(rect3)

class Rectangle:
    def __init__(self, width, height):
        self.width=width
        self.height=height
    def area(self):
        return self.width*self.height
    def __str__(self):
        return f"Rectangle width: {self.width} height: {self.height}"

rect4=Rectangle(8,10)
print(rect4.width)
print(rect4.height)
print(rect4.area())
print(rect4)