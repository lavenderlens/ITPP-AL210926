def print_sum(numbers):
    sum = 0
    for num in numbers:
        sum += num
    print(sum)

print_sum([1,2,3])

def print_product(numbers):
    product = 1
    for num in numbers:
        product = product * num
    print(product)

print_product([4,2])

def print_product(number1, number2):
    product = number1*number2
    print(product)

number1=num1=float(input("Enter the first number"))
number2=num2=float(input("Enter the second number"))

operation=int(input("Enter 1 for sum or 2 for product: "))

if operation == 1:
    print_sum(number1, number2)
elif operation == 2:
    print_product(num1, num2)
else:
    print("Error, choose 1 or 2!")
