def greet():
    print("Hello")
    print("How are you?")
print("Carrying on...")
greet()

def greet_to(name='friend', age=36):
    year_of_birth = 2026-age
    print(f"Hello {name}")
    print(f"You were born in {year_of_birth}")

def print_all(list):
    for el in list:
        print(el)

def print_sum(numbers):
    sum = 0
    for num in numbers:
        sum += num
    print(sum)

def get_sum(numbers):
    sum=0
    for num in numbers:
        sum += num
    return sum